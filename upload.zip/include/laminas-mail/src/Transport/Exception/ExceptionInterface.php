<?php

namespace Laminas\Mail\Transport\Exception;

use Laminas\Mail\Exception\ExceptionInterface as MailException;

interface ExceptionInterface extends MailException
{
}
